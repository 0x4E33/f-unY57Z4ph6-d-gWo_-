# Ubuntu Deployment

This project includes a one-click deployment script for Ubuntu servers:

```bash
sudo bash deploy-ubuntu.sh
```

## What the script does

- Installs missing system packages with `apt`
- Installs `Node.js` and `npm` if they are not present
- Installs project dependencies
- Builds the React site
- Publishes the built files into `/var/www/mimodesignlab-quiz-cutie-hero`
- Configures `nginx`
- Enables and restarts `nginx`
- Opens `Nginx Full` in `ufw` if `ufw` is active
- Claims the default HTTP entry with `default_server` so direct IP access resolves to this site

## Default behavior

- `DOMAIN` defaults to `_`
- Static files are served from:
  `/var/www/mimodesignlab-quiz-cutie-hero/current`

That means the site can be accessed by server IP immediately after deployment.

## Common usage

Deploy with server IP access only:

```bash
sudo bash deploy-ubuntu.sh
```

Deploy with a real domain:

```bash
sudo DOMAIN=example.com bash deploy-ubuntu.sh
```

Skip the build and reuse an existing local `dist/`:

```bash
sudo SKIP_BUILD=1 bash deploy-ubuntu.sh
```

Use a different Node major version:

```bash
sudo NODE_MAJOR=22 bash deploy-ubuntu.sh
```

## Notes

- Run the script from the project root.
- The script is intended for Ubuntu with `apt`.
- HTTPS is not configured automatically. If you later bind a domain, you can add SSL with Certbot.
