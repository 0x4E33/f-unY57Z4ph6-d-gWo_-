import LegalPage from "../components/LegalPage";
import { company, legalLastUpdated } from "../data";

const sections = [
  {
    title: "1. Scope",
    paragraphs: [
      `These Terms of Service apply to the public-facing website operated by ${company.name} for the presentation of the game ${company.gameName}.`,
      "By browsing or using this website, you agree to use it lawfully and in a way that does not interfere with its normal operation.",
    ],
  },
  {
    title: "2. Informational Use",
    paragraphs: [
      "This website is intended to provide company, game, and contact information.",
      "Unless we clearly state otherwise, the site does not create a user account, does not provide paid digital services directly, and does not promise gameplay availability in every region or on every platform.",
    ],
  },
  {
    title: "3. Intellectual Property",
    paragraphs: [
      "The company name, logo, website design, game title, screenshots, and related visual materials on this site are owned by or used with permission by MIMODESIGNLAB LLC.",
      "You may view the site for personal and informational purposes, but you may not copy, republish, distribute, or commercially exploit site content without prior written permission.",
    ],
  },
  {
    title: "4. Acceptable Conduct",
    paragraphs: [
      "You agree not to misuse the site, attempt unauthorized access, introduce malicious code, or use the site in a way that could damage its operation or harm other users.",
    ],
    items: [
      "Do not impersonate our company or misrepresent an affiliation.",
      "Do not scrape or reproduce content for misleading or unlawful use.",
      "Do not submit false or abusive communications through our contact methods.",
    ],
  },
  {
    title: "5. External Links and Future Distribution",
    paragraphs: [
      "If the site later links to third-party stores, platforms, or external services, those services will be governed by their own terms and policies.",
      `If ${company.gameName} is distributed through app stores or other platforms, additional end-user terms may apply to the game itself.`,
    ],
  },
  {
    title: "6. No Warranty",
    paragraphs: [
      "We aim to keep the site accurate and current, but the site is provided on an 'as is' and 'as available' basis.",
      "We do not guarantee uninterrupted access, error-free content, or that all information will always remain complete or current.",
    ],
  },
  {
    title: "7. Limitation of Liability",
    paragraphs: [
      "To the extent permitted by applicable law, MIMODESIGNLAB LLC will not be liable for indirect, incidental, or consequential losses arising from use of this website.",
      "Nothing in these Terms limits rights that cannot be limited under applicable law.",
    ],
  },
  {
    title: "8. Changes",
    paragraphs: [
      "We may update these Terms from time to time by posting a revised version on this page and updating the last updated date.",
    ],
  },
  {
    title: "9. Contact",
    paragraphs: [
      `Questions about these Terms may be sent to ${company.email}. Company address: ${company.address}.`,
    ],
  },
];

export default function TermsPage() {
  return (
    <LegalPage
      title="Terms of Service"
      lastUpdated={legalLastUpdated}
      sections={sections}
    />
  );
}
