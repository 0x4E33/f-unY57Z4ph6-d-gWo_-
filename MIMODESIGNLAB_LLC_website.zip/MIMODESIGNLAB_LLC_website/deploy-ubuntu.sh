#!/usr/bin/env bash

set -Eeuo pipefail

APP_NAME="mimodesignlab-quiz-cutie-hero"
DEFAULT_DOMAIN="_"
DEFAULT_SITE_DIR="/var/www/${APP_NAME}"
DEFAULT_NGINX_CONF="/etc/nginx/sites-available/${APP_NAME}.conf"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DOMAIN="${DOMAIN:-$DEFAULT_DOMAIN}"
SITE_DIR="${SITE_DIR:-$DEFAULT_SITE_DIR}"
SITE_USER="${SITE_USER:-www-data}"
SITE_GROUP="${SITE_GROUP:-www-data}"
NGINX_CONF_PATH="${NGINX_CONF_PATH:-$DEFAULT_NGINX_CONF}"
NODE_MAJOR="${NODE_MAJOR:-20}"
SKIP_BUILD="${SKIP_BUILD:-0}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Please run this script with sudo or as root."
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive

log() {
  printf '\n[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1"
}

fail() {
  echo "Error: $1" >&2
  exit 1
}

require_command() {
  command -v "$1" >/dev/null 2>&1
}

ensure_project_files() {
  [[ -f "${PROJECT_DIR}/package.json" ]] || fail "package.json not found in ${PROJECT_DIR}"
  [[ -f "${PROJECT_DIR}/index.html" ]] || fail "index.html not found in ${PROJECT_DIR}"
}

install_base_packages() {
  log "Updating apt package index"
  apt-get update -y

  log "Installing required system packages"
  apt-get install -y \
    ca-certificates \
    curl \
    gnupg \
    lsb-release \
    nginx \
    unzip \
    rsync
}

install_nodejs_if_needed() {
  if require_command node && require_command npm; then
    log "Node.js already installed: $(node -v), npm: $(npm -v)"
    return
  fi

  if ! require_command node; then
    log "Installing Node.js ${NODE_MAJOR}.x"
    mkdir -p /etc/apt/keyrings

    if [[ ! -f /etc/apt/keyrings/nodesource.gpg ]]; then
      curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \
        | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
    fi

    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" \
      > /etc/apt/sources.list.d/nodesource.list

    apt-get update -y
    apt-get install -y nodejs
  fi

  if ! require_command npm; then
    log "npm is missing; installing npm package"
    apt-get install -y npm
  fi

  require_command node || fail "Node.js installation failed"
  require_command npm || fail "npm installation failed"

  log "Installed Node.js: $(node -v), npm: $(npm -v)"
}

build_project() {
  if [[ "${SKIP_BUILD}" == "1" ]]; then
    log "Skipping build because SKIP_BUILD=1"
    return
  fi

  cd "${PROJECT_DIR}"

  if [[ -f package-lock.json ]]; then
    log "Installing project dependencies with npm ci"
    npm ci
  else
    log "Installing project dependencies with npm install"
    npm install
  fi

  log "Building production assets"
  npm run build

  [[ -f "${PROJECT_DIR}/dist/index.html" ]] || fail "Build finished but dist/index.html was not generated"
}

sync_site_files() {
  local target_current="${SITE_DIR}/current"
  local target_releases="${SITE_DIR}/releases/$(date '+%Y%m%d%H%M%S')"

  log "Preparing target directories under ${SITE_DIR}"
  mkdir -p "${target_releases}"
  mkdir -p "${SITE_DIR}/shared"

  log "Copying built files to release directory"
  rsync -a --delete "${PROJECT_DIR}/dist/" "${target_releases}/"

  ln -sfn "${target_releases}" "${target_current}"
  chown -R "${SITE_USER}:${SITE_GROUP}" "${SITE_DIR}"
}

disable_default_nginx_site() {
  log "Disabling nginx default site if present"
  rm -f /etc/nginx/sites-enabled/default
  rm -f /etc/nginx/sites-available/default
  rm -f /etc/nginx/conf.d/default.conf
}

write_nginx_config() {
  log "Writing nginx site config to ${NGINX_CONF_PATH}"

  mkdir -p /etc/nginx/sites-available
  mkdir -p /etc/nginx/sites-enabled

  cat > "${NGINX_CONF_PATH}" <<EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name ${DOMAIN};

    root ${SITE_DIR}/current;
    index index.html;

    access_log /var/log/nginx/${APP_NAME}.access.log;
    error_log /var/log/nginx/${APP_NAME}.error.log;

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|svg|ico|webp|woff|woff2)$ {
        expires 7d;
        add_header Cache-Control "public, max-age=604800, immutable";
        try_files \$uri =404;
    }
}
EOF

  ln -sfn "${NGINX_CONF_PATH}" "/etc/nginx/sites-enabled/${APP_NAME}.conf"
}

configure_firewall() {
  if require_command ufw; then
    local ufw_status
    ufw_status="$(ufw status 2>/dev/null || true)"
    if grep -q "Status: active" <<<"${ufw_status}"; then
      log "Allowing nginx through ufw"
      ufw allow 'Nginx Full' >/dev/null 2>&1 || true
    fi
  fi
}

reload_nginx() {
  log "Testing nginx configuration"
  nginx -t

  log "Enabling and restarting nginx"
  systemctl enable nginx
  systemctl restart nginx
}

print_summary() {
  cat <<EOF

Deployment complete.

Project directory: ${PROJECT_DIR}
Published site:    ${SITE_DIR}/current
Domain:            ${DOMAIN}
Nginx config:      ${NGINX_CONF_PATH}

Useful commands:
  sudo systemctl status nginx
  sudo nginx -t
  sudo tail -f /var/log/nginx/${APP_NAME}.error.log

If you have a real domain, point its DNS A record to this server and rerun with:
  sudo DOMAIN=your-domain.com bash deploy-ubuntu.sh
EOF
}

main() {
  ensure_project_files
  install_base_packages
  install_nodejs_if_needed
  build_project
  sync_site_files
  disable_default_nginx_site
  write_nginx_config
  disable_default_nginx_site
  configure_firewall
  reload_nginx
  print_summary
}

main "$@"
