import aboutOffice from "./assets/images/about-office.png";

export const company = {
  name: "MIMODESIGNLAB LLC",
  email: "official@mimodesign.org",
  phone: "+1 3074106576",
  address: "30 N Gould St Ste R Sheridan, WY 82801",
  gameName: "Quiz Cutie Hero",
  aboutImage: aboutOffice,
};

export const screenshots = [
  {
    src: "/GAME_SCREENSHOT_1.jpeg",
    alt: "Quiz Cutie Hero home screen with adventure and progression cards.",
    label: "Main Menu",
  },
  {
    src: "/GAME_SCREENSHOT_2.jpeg",
    alt: "Quiz Cutie Hero welcome back reward pop-up.",
    label: "Idle Rewards",
  },
  {
    src: "/GAME_SCREENSHOT_3.jpeg",
    alt: "Quiz Cutie Hero combat scene with question prompt and answer choices.",
    label: "Quiz Battle",
  },
  {
    src: "/GAME_SCREENSHOT_4.jpeg",
    alt: "Quiz Cutie Hero stat upgrade interface.",
    label: "Upgrades",
  },
  {
    src: "/GAME_SCREENSHOT_5.jpeg",
    alt: "Quiz Cutie Hero skin selection interface.",
    label: "Skins",
  },
  {
    src: "/GAME_SCREENSHOT_6.jpeg",
    alt: "Quiz Cutie Hero item shop interface.",
    label: "Shop",
  },
];

export const highlights = [
  {
    eyebrow: "Quiz + Battle",
    title: "Answer quickly, push through each encounter.",
    text: "Core combat is framed around lightweight quiz prompts, turning each stage into a clear, easy-to-follow loop that feels active without becoming heavy.",
  },
  {
    eyebrow: "Collection",
    title: "Unlock skins, items, and growth paths.",
    text: "Players can move between combat, upgrades, skin changes, and item choices, giving the game a stronger sense of ownership and progression.",
  },
  {
    eyebrow: "Session Design",
    title: "Built for approachable play sessions.",
    text: "The interface supports short returns, reward collection, and visible progress so users can understand value fast and keep momentum.",
  },
];

export const homeSections = [
  {
    title: "Readable fantasy UI",
    text: "Bright cards, soft glows, and familiar menu structures help first-time users understand the game quickly.",
  },
  {
    title: "Progress that feels visible",
    text: "Stat growth, coins, and unlockables are surfaced clearly, making each return session feel worthwhile.",
  },
  {
    title: "Character-driven presentation",
    text: "Hero art and skin variants give the experience a stronger identity without overcomplicating the loop.",
  },
];

export const legalLastUpdated = "March 27, 2026";
