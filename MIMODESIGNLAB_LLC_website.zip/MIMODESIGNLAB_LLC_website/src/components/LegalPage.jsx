import SectionTitle from "./SectionTitle";

export default function LegalPage({ eyebrow, title, lastUpdated, sections }) {
  return (
    <div className="legal-page page-shell">
      <section className="page-hero compact-hero" data-reveal>
        <div className="page-hero-copy narrow" data-reveal>
          <SectionTitle
            eyebrow={eyebrow}
            title={title}
            text={`Last updated: ${lastUpdated}`}
          />
        </div>
      </section>

      <section className="legal-content">
        {sections.map((section) => (
          <article key={section.title} className="legal-block glass-card" data-reveal>
            {section.title ? <h3>{section.title}</h3> : null}
            {section.paragraphs.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
            {section.items ? (
              <ul>
                {section.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            ) : null}
            {section.postParagraphs
              ? section.postParagraphs.map((paragraph) => (
                  <p key={paragraph}>{paragraph}</p>
                ))
              : null}
          </article>
        ))}
      </section>
    </div>
  );
}
