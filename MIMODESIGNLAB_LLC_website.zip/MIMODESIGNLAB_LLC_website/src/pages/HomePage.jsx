import { Link } from "react-router-dom";
import SectionTitle from "../components/SectionTitle";
import { company, highlights, homeSections, screenshots } from "../data";

export default function HomePage() {
  const scrollToScreenshots = () => {
    document.getElementById("screenshots")?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  const featured = screenshots[0];
  const battle = screenshots[2];
  const upgrade = screenshots[3];
  const skins = screenshots[4];

  return (
    <div className="home-page">
      <section className="hero-panel page-shell">
        <div className="hero-copy" data-reveal>
          <span className="eyebrow">Fantasy Quiz Adventure</span>
          <h1 className="hero-title">QUIZ CUTIE HERO</h1>
          <div className="hero-actions">
            <button type="button" className="primary-btn" onClick={scrollToScreenshots}>
              Explore the Game
            </button>
            <Link to="/contact" className="secondary-btn">
              Contact Our Team
            </Link>
          </div>
          <div className="hero-stats">
            <div>
              <strong>01</strong>
              <span>Quiz battle</span>
            </div>
            <div>
              <strong>02</strong>
              <span>Hero skins and upgrades</span>
            </div>
            <div>
              <strong>03</strong>
              <span>Return-friendly reward flow</span>
            </div>
          </div>
        </div>

        <div className="hero-visual" data-reveal>
          <div className="visual-card visual-card-main">
            <img src={featured.src} alt={featured.alt} />
          </div>
          <div className="visual-card visual-card-float visual-card-a">
            <img src={battle.src} alt={battle.alt} />
          </div>
          <div className="visual-card visual-card-float visual-card-b">
            <img src={skins.src} alt={skins.alt} />
          </div>
        </div>
      </section>

      <section className="feature-band page-shell">
        {homeSections.map((item) => (
          <article key={item.title} className="glass-card info-card" data-reveal>
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </article>
        ))}
      </section>

      <section className="content-section page-shell" data-reveal>
        <SectionTitle
          eyebrow="Gameplay Snapshot"
          title="A clear loop that blends battle presentation with easy-to-read quiz interaction."
          text="The screenshots below are used to show how the product communicates progression, rewards, and character identity without overloading the player."
        />

        <div className="spotlight-grid">
          <article className="spotlight-copy glass-card" data-reveal>
            <span className="mini-label">Quiz Combat</span>
            <h3>Answer, react, and keep moving.</h3>
            <p>
              Combat screens use a layered fantasy backdrop, clear answer
              buttons, and readable health feedback to make the result of each
              decision understandable at a glance.
            </p>
          </article>

          <article className="spotlight-media glass-card" data-reveal>
            <img src={battle.src} alt={battle.alt} />
          </article>
        </div>
      </section>

      <section id="screenshots" className="content-section page-shell" data-reveal>
        <SectionTitle
          eyebrow="In-Game Views"
          title="Menus, rewards, upgrades, skins, and shop layers are all part of the landing story."
          text="With limited source material, the page uses cropping, motion, and contrast to create depth while staying faithful to the actual game presentation."
        />

        <div className="screenshot-grid">
          {screenshots.map((item, index) => (
            <article
              key={item.label}
              className={`screenshot-card screenshot-card-${
                index === 0 ? "wide" : "standard"
              }`}
              data-reveal
            >
              <div className="shot-badge">{item.label}</div>
              <img src={item.src} alt={item.alt} />
            </article>
          ))}
        </div>
      </section>

      <section className="content-section page-shell" data-reveal>
        <SectionTitle
          eyebrow="Player Motivation"
          title="The product story is built around momentum rather than complexity."
          text="Every content block on the homepage points back to the same promise: approachable sessions, visible rewards, and a game identity users can recognize quickly."
        />

        <div className="highlights-grid">
          {highlights.map((item) => (
            <article key={item.title} className="glass-card highlight-card" data-reveal>
              <span className="mini-label">{item.eyebrow}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="content-section page-shell split-section" data-reveal>
        <div className="split-copy" data-reveal>
          <SectionTitle
            eyebrow="Systems Overview"
            title="Progression content supports retention without forcing a complicated learning curve."
            text="Upgrade panels, skin options, return rewards, and store items create multiple reasons to continue, while still feeling easy to understand."
          />
          <div className="timeline-list">
            <div className="timeline-item">
              <strong>Battle</strong>
              <p>Stage-based quiz encounters keep play readable and direct.</p>
            </div>
            <div className="timeline-item">
              <strong>Reward</strong>
              <p>Return bonuses and coins reinforce short-session value.</p>
            </div>
            <div className="timeline-item">
              <strong>Grow</strong>
              <p>Stats, skins, and shop items widen the progression layer.</p>
            </div>
          </div>
        </div>

        <div className="stacked-media" data-reveal>
          <div className="glass-card media-frame media-frame-front" data-reveal>
            <img src={upgrade.src} alt={upgrade.alt} />
          </div>
          <div className="glass-card media-frame media-frame-back" data-reveal>
            <img src="/GAME_SCREENSHOT_2.jpeg" alt="Quiz Cutie Hero return reward screen." />
          </div>
        </div>
      </section>

      <section className="cta-panel page-shell" data-reveal>
        <div className="glass-card cta-card" data-reveal>
          <span className="eyebrow">Studio Contact</span>
          <h2>Looking for partnership, publishing, or company information?</h2>
          <p>
            Reach out to MIMODESIGNLAB LLC for business inquiries, media
            requests, or product questions related to {company.gameName}.
          </p>
          <Link to="/contact" className="primary-btn">
            Open Contact Page
          </Link>
        </div>
      </section>
    </div>
  );
}
