import LegalPage from "../components/LegalPage";
import { company, legalLastUpdated } from "../data";

const sections = [
  {
    title: "",
    paragraphs: [
      `This Privacy Policy describes how ${company.name} ("we", "us", or "our") approaches privacy in connection with the mobile game ${company.gameName} (the "Game"). By downloading, accessing, or using the Game, you accept the terms of this Privacy Policy. We present this policy with the goal of supporting a secure player experience and in a manner intended to align with Google Play Developer Policies and applicable privacy frameworks such as GDPR, CCPA, and COPPA.`,
    ],
  },
  {
    title: "1. Third-Party Services",
    paragraphs: [
      "The Game is not presented here as using third-party analytics services, advertising SDKs, or social media integrations for user tracking.",
      "Because we do not describe the Game as collecting player data in the first place, we also do not describe ourselves as selling, renting, sharing, or transferring that user data to outside parties.",
      "Google Play Services may still be involved for distribution, installation, or updates, but this policy does not state that we provide user data to Google or to other third parties through the Game for tracking purposes.",
    ],
  },
  {
    title: "2. Information We Collect",
    paragraphs: [
      "To support gameplay, we do not state that we collect personal information, sensitive data, or user identifiers from players. More specifically:",
    ],
    items: [
      "We do not collect your name, email address, phone number, location, or other personally identifiable information.",
      "We do not collect device information, usage data, crash logs, or information about your gameplay habits.",
      "We do not integrate third-party analytics, advertising SDKs, or similar tracking tools that collect user data.",
    ],
  },
  {
    title: "3. Data Security",
    paragraphs: [
      "We take reasonable measures, consistent with ordinary industry expectations, to support the safety of locally stored game information.",
      "Since gameplay data remains on your device and is not transmitted to our servers as part of the practices described here, protection of that data depends largely on your own device security. We recommend keeping your device updated and using suitable device lock or access protection measures.",
    ],
  },
  {
    title: "4. Local Data Storage",
    paragraphs: [
      "Game-related information is stored locally on your device only and is not transmitted by us to our own servers or to third parties in the ordinary operation of the Game.",
      "That locally stored information may include game progress, current game state, settings, and saved preferences where applicable.",
      "Such information relies on your device's native local storage and may be permanently removed if you uninstall the Game. We do not state that we can remotely retrieve, inspect, or modify that local gameplay data.",
    ],
  },
  {
    title: "5. Changes to This Privacy Policy",
    paragraphs: [
      'We may revise this Privacy Policy from time to time to reflect updates to our practices or to applicable legal requirements. When changes are made, we will update the "Last Updated" date shown on this page. Continued use of the Game after a revision means you accept the updated Privacy Policy.',
    ],
  },
  {
    title: "6. Children's Privacy",
    paragraphs: [
      "The Game is described as suitable for users of all ages and is not presented as targeting children under 13 for personal information collection.",
      "We do not state that we collect personal information from children or from users of any age through the Game, and we intend this policy to remain consistent with COPPA and other applicable children's privacy requirements.",
    ],
  },
  {
    title: "7. Contact Us",
    paragraphs: [
      `If you have any questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us at: ${company.email}`,
    ],
  },
];

export default function PrivacyPage() {
  return (
    <LegalPage
      title="Privacy Policy"
      lastUpdated={legalLastUpdated}
      sections={sections}
    />
  );
}
