import { useState } from "react";
import SectionTitle from "../components/SectionTitle";
import { company } from "../data";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const subject = encodeURIComponent(
      formData.subject || `Inquiry about ${company.gameName}`,
    );
    const body = encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`,
    );
    window.location.href = `mailto:${company.email}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="contact-page page-shell">
      <section className="page-hero compact-hero" data-reveal>
        <div className="page-hero-copy" data-reveal>
          <SectionTitle
            title="Contact Us"
          />
        </div>
      </section>

      <section className="contact-layout">
        <article className="glass-card contact-details" data-reveal>
          <h3>Company Details</h3>
          <p>
            <strong>Company:</strong> {company.name}
          </p>
          <p>
            <strong>Email:</strong>{" "}
            <a id="contact-mail" href={`mailto:${company.email}`}>
              {company.email}
            </a>
          </p>
          <p>
            <strong>Phone:</strong>{" "}
            <a href={`tel:${company.phone.replace(/\s+/g, "")}`}>
              {company.phone}
            </a>
          </p>
          <p>
            <strong>Address:</strong> {company.address}
          </p>
        </article>

        <form className="glass-card contact-form" onSubmit={handleSubmit} data-reveal>
          <label>
            Name
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Your name"
              required
            />
          </label>
          <label>
            Email
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
            />
          </label>
          <label>
            Subject
            <input
              type="text"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              placeholder="Business inquiry"
            />
          </label>
          <label>
            Message
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder="Tell us about your request."
              rows="7"
              required
            />
          </label>
          <button type="submit" className="primary-btn full-width">
            Open Email Draft
          </button>
        </form>
      </section>
    </div>
  );
}
