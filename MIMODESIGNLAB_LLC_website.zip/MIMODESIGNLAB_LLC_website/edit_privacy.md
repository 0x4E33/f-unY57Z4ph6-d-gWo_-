This Privacy Policy governs your use of the mobile game (the "Game") developed by Xiaoyoumin_Game (referred to as "we", "us", or "our"). By accessing or using the Game, you agree to the terms and conditions of this Privacy Policy. We are committed to protecting your privacy and ensuring a secure gaming experience, in compliance with Google Play Developer Policies and global data protection laws including GDPR, CCPA, and COPPA.

\1. Information We Collect

To provide and enhance your gaming experience, we do not collect any personal information, sensitive data, or user identifiers from you. Specifically:

We do not collect your name, email address, phone number, location, or any other personally identifiable information.

We do not collect device information, usage data, crash logs, or any data related to your gameplay habits.

We do not integrate any third-party analytics, advertising SDKs, or tracking tools that collect user data.

\2. Local Data Storage

All game-related data is stored locally on your device only and is never transmitted to our servers or any third parties. This locally stored data includes:

Your game progress (e.g., completed levels, current game state).

Game settings and preferences (if applicable).

This data is stored using your device’s native local storage and will be permanently deleted if you uninstall the Game. We have no access to this local data and cannot retrieve or modify it.

\3. Third-Party Services

The Game does not use any third-party services, including but not limited to advertising networks, analytics tools, or social media integrations. We do not share, sell, rent, or transfer any user data to third parties, as we do not collect any such data in the first place. Google Play Services may be used solely for app distribution and updates, and we do not share any user data with Google or other third parties through these services.

\4. Children’s Privacy

The Game is suitable for users of all ages and does not target children under the age of 13. We do not collect any personal information from anyone, including children, and fully comply with the Children’s Online Privacy Protection Act (COPPA) and other applicable laws regarding children’s privacy. No parental consent is required to use the Game, as we do not collect any data from users of any age.

\5. Data Security

We take reasonable measures to protect the local data stored on your device, in line with industry standards. Since all game data is stored locally and not transmitted to our servers, the security of this data is primarily dependent on your device’s security settings. We recommend keeping your device updated and using secure lock screen measures to protect your data.

\6. Changes to This Privacy Policy

We may update this Privacy Policy from time to time to reflect changes in our practices or applicable laws. When we make changes, we will update the "Last Updated" date at the top of this policy. Your continued use of the Game after any changes indicates your acceptance of the updated Privacy Policy.

\7. Contact Us

If you have any questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us at: hongjielv36@gmail.com