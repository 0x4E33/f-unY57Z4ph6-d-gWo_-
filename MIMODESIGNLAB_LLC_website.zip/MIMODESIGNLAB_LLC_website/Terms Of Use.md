The following terms and conditions ("Terms") apply to your use of the online services of MONCH INC, and their affiliates ("MONCH", "we" "us" or "our"), including any content, functionality, products, and services offered on or through the MONCH websites, devices, software, hardware or the cloud (collectively, the "Platform"), whether as a guest or a registered user. These Terms also apply to your use of other MONCH services that display or include these Terms ("Additional Services"). In these Terms, the Platform and Additional Services are collectively referred to as the "Services."

Please read these Terms carefully before you start to use the Services. By using the Services, you accept and agree to be bound and abide by these Terms of Use. If you do not want to agree to these Terms of Use, you must not use the Services. In particular, we want to highlight some important terms, policies, and procedures in these Terms. By accepting these Terms:

- \1. You are also agreeing to other MONCH rules and policies that are expressly incorporated into and a part of these Terms. Please read them carefully:
    **Our Privacy Policy explains what information we collect from you and how we protect it.**
- \2. You and MONCH agree to resolve disputes between us in individual arbitration (not in court). We believe the alternative dispute-resolution process of arbitration will resolve any dispute fairly and more quickly and efficiently than formal court litigation. We explain the process in detail below, but we've put this up front (and in caps) because it's important:

THESE TERMS CONTAIN A BINDING, INDIVIDUAL ARBITRATION AND CLASS-ACTION WAIVER PROVISION. IF YOU ACCEPT THESE TERMS, YOU AND MONCH AGREE TO RESOLVE DISPUTES IN BINDING, INDIVIDUAL ARBITRATION AND GIVE UP THE RIGHT TO GO TO COURT INDIVIDUALLY OR AS PART OF A CLASS ACTION, AND MONCH WILL NOT PAY YOUR ARBITRATION COSTS FOR ANY DISPUTES.

TO ENTER INTO THE CONTRACT CREATED BY THESE TERMS, YOU MUST BE AN ADULT OF THE LEGAL AGE OF MAJORITY IN YOUR COUNTRY OF RESIDENCE. You are legally and financially responsible for all actions using or accessing our Services, including the actions of anyone you allow to access your account. You affirm that you have reached the legal age of majority, and understand and accept these terms (including its dispute resolution terms). If you are under the legal age of majority, your parent or legal guardian must consent to these terms.

In addition to these Terms, software or services that are included in or otherwise made available to you through the Services may be subject to separate agreement between you and MONCH. If these Terms are inconsistent with any such agreements, those agreements will control.

## Privacy Notice

Please review our Privacy Notice found at https://monchinc.com/privacy_policy.html,which also governs your use of the Services, to understand our privacy practices and how we protect your personal information.

## Changes to the Terms of Use

We may update these Terms from time to time; you should check this page regularly to take notice of any changes. Your continued use of the Services following the posting of revised Terms means that you accept and agree to the changes.

## Accessing the Services and Account Security

We may withdraw or amend the Services, and any related service or content, or restrict access (including by means of cancellation, termination, or modification, or suspension of a user account) to all or certain users (including you) without notice and without liability to you in our reasonable discretion. Additionally, due to your geographic location, the Services or some of their features, services, or content may be unavailable to you. Notwithstanding anything to the contrary herein, we may terminate or suspend access to the Services based on your breach of these Terms.

To access certain Services, you will be asked to provide registration details or other information, and in order to use such resources, all the information you provide must be correct, current, and complete. From time to time, in order to access the Services or certain games, services, or functionality, MONCH may require some or all users to download updated or additional software. The terms of use of such software may be subject to separate agreement between you and MONCH.

If you choose, or are provided with a user name, password, or any other piece of information as part of our security procedures, you must treat such information as confidential (other than user name), and you must not disclose it to others. You must immediately notify MONCH of any unauthorized use of your user name or password or any other breach of security. You should use particular caution when accessing your account from a public or shared computer so that others are not able to view or record your password or other personal information. You may only access the Services through your own account. Users do not own their accounts, and gifting or otherwise transferring of accounts or access keys is prohibited.

We reserve the right to change your display name if we deem it offensive, misleading, potentially infringing the rights of third parties or if you have been inactive for more than a year.

## Intellectual Property Rights

The Services, including but not limited to, MONCH's logos, and all designs, text, graphics, pictures, information, data, software, sound files, other files and the selection and arrangement thereof, content, features, and functionality thereof, are owned by MONCH, its licensors, or other providers of such material and are protected by United States and international copyright, trademark, patent, and other intellectual property or proprietary rights laws.

You are permitted to use the Services for your personal, non-commercial use only or legitimate business purposes related to your role as a current or prospective customer of MONCH. Except as provided below, you must not copy, modify, create derivative works of, publicly display, publicly perform, republish, or transmit any of the material obtained through the Services, or delete, or alter any copyright, trademark, or other proprietary rights notices from copies of materials from the Services. However, if you are otherwise in compliance with these Terms, you are permitted to use, elsewhere and on other websites, an unaltered copy of portions of the content that is publicly available on the Platform for the limited, non-commercial purpose of discussing such content.

You must not reproduce, sell, or exploit for any commercial purposes any part of the Services, access to the Services or use of the Services or any services or materials available through the Services.

For clarity, the foregoing permissions are limited to the Services, and no rights are granted with respect to any servers, computers, or databases associated with the Services.

## Eligibility

In order to use our Services, you must meet the following eligibility criteria:

You must not be located in a country that is subject to the United States government embargo, or that has been designated by the United States government as a "terrorist supporting" country.

You must not be listed on any United States government list of prohibited or restricted parties.

## You must be at least 13 years of age.

If you are under 18 years of age (or the age of legal majority where you live), you may use our Services only under the supervision of a parent or legal guardian who agrees to be bound by these Terms. If you are a parent or legal guardian of a user under the age of 18 (or the age of legal majority), you agree to be fully responsible for the acts or omissions of such user in relation to our Services. If you use our Services on behalf of another person or entity, (a) all references to "you" throughout these Terms will include that person or entity, (b) you represent that you are authorized to accept these Terms on that person's or entity's behalf, and (c) in the event you or the person or entity violates these Terms, both you and the person or entity agree to be responsible to us.

## Your User Account and Account Security

You may need to register for an account to access our Services. When you register for an account, you must provide accurate account information and promptly update this information if it changes. You also must maintain the security of your account and promptly notify us if you discover or suspect that someone has accessed your account without your permission. You must not permit others to use your account credentials. You are responsible for the activities of any users that occur in connection with your account. We reserve the right to reclaim usernames, including on behalf of businesses or individuals that hold legal claim, including trademark rights, in those usernames.

Access to your account is limited solely to you. You will not sell, rent, lease, or grant access to your account to any person without our prior written permission.

You are solely responsible for maintaining the security of your account and control over any usernames, passwords, or any other codes that you use to access our Services. You will not hold us responsible for managing and maintaining the security of your account. We are not responsible (and you will not hold us responsible) for any unauthorized access to or use of your account. You are responsible for monitoring your account. If you notice any unauthorized or suspicious activity in your account, please notify us immediately.

## Suspension of Account

We have the right to immediately suspend your account, pause or cancel your access to our Services, or close your account if we suspect, in our sole discretion, that Your account is being used for money laundering, to evade sanctions or to engage in illegal activity, You have concealed or provided false identification information or other details, You have engaged in fraudulent activity, or You have engaged in transactions in violation of these Terms.

## License to Services and Ownership

Our Services, including the text, graphics, images, photographs, videos, illustrations and other content contained therein, are owned by or our licensors and are protected under both United States and foreign laws. Except as explicitly stated in these Terms, all rights in and to our Services are reserved by us or our licensors. Subject to your compliance with these Terms, you are hereby granted a limited, nonexclusive, nontransferable, non-sublicensable, revocable license to access and use our Services for your own personal, noncommercial use. Any use of our Services other than as specifically authorized herein, without our prior written permission, is strictly prohibited, will terminate the license granted herein and violate our intellectual property rights.

## Related Content - Restrictions

You will not, attempt to, or permit or enable any third party to: (a) modify the Related Content, unless expressly permitted to do so pursuant to the Digital Collectible Terms; (b) register or attempt to register any trademark or copyright or otherwise acquire additional intellectual property rights in or to any Related Content; (c) use any Related Content to create, endorse, support, promote or condone any content, material or speech that is defamatory, obscene, pornographic, indecent, abusive, offensive, harassing, violent, hateful, racist, discriminatory, inflammatory or otherwise objectionable or inappropriate as determined by at its sole discretion; (d) commercialize the Related Content or use the Related Content in connection with any business, message, product, or service, or in any manner that may imply endorsement of any business, message, product, or service; (e) use the Related Content in any manner that is likely to cause confusion or dilute, blur, or tarnish the Related Content or any intellectual property rights in the Related Content; or (f) use the Related Content in any manner that infringes, violates or misappropriates any third party intellectual property or intellectual property right, or that violates the these Terms or the Digital Collectible Terms.

## Third Party Content

We may provide information about Additional Benefits made available by third parties or other third-party products, services, activities or events, or we may allow third parties to make their content and information available on or through our Services (collectively, "Third-Party Content"). We provide Third-Party Content as a service to those interested in such content. Your dealings or correspondence with third parties and your use of or interaction with any Third-Party Content are solely between you and the third party. does not control or endorse, and makes no representations or warranties regarding, any Third-Party Content, and your access to and use of such Third-Party Content is at your own risk.

## Prohibited Uses

You may use the Services only for lawful purposes and in accordance with these Terms of Use. You agree not to access or use the Services for any purpose that is illegal or beyond the scope of the Services' intended use (in MONCH's sole judgment).

You further agree not to:

Engage in any discriminatory, defamatory, libelous, hateful, harassing, abusive, obscene, threatening, physically dangerous, unlawful, or otherwise objectionable conduct; Attempt to indicate in any manner that you have a relationship with us or that we have endorsed you or any products or services for any purpose; Send any unsolicited or unauthorized advertising, solicitations, promotional materials, spam, junk mail, chain letters or pyramid schemes, or harvest or collect the email addresses or other contact information of other users from the Services for the purpose of sending spam or other commercial messages; Attempt to reverse engineer any aspect of the Services or do anything that might discover source code or bypass or circumvent measures employed to prevent or limit access to any area, content or code of the Services (except as otherwise expressly permitted by law); Post, upload to, transmit, distribute, store, create or otherwise publish or send through the Services viruses, corrupted data or other harmful, disruptive or destructive files; Develop any third-party applications that interact with User Content or the Services without our prior written consent; or Use any robot, iframe, spider, crawler, scraper or other automated means or interface not provided by us to access the Services, including, without limitation, for the purpose of copying, extracting, aggregating, displaying, publishing or distributing any content or data made available via Services.

## User Contributions

The Services do or may contain various forums, networks, and other interactive features that allow you to post, submit, publish, display, or transmit to MONCH and other users ("Post") content or materials ("User Contributions") on or through the Services.

All User Contributions must comply with the following content standards: User Contributions must not be illegal, fraudulent, deceptive, obscene, threatening, defamatory, invasive of privacy, infringing of intellectual property rights, or otherwise injurious to third parties or objectionable, and must not consist of or contain software viruses, commercial solicitation, chain letters, mass mailings, or any form of "spam."

Any User Contribution that you Post will be considered non-confidential and non-proprietary, and you grant MONCH a nonexclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, copy, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such User Contribution throughout the world in any media; however, MONCH will only share personal information that you provide in accordance with MONCH's Privacy Policy.

You represent and warrant that you own or otherwise control all of the rights to the User Contributions that you Post at the time of Posting; that the User Contributions are accurate and not fraudulent or deceptive; and that the User Contributions do not violate these Terms or the rights (intellectual property rights or otherwise) of any third party, and will not cause injury to any person or entity. You understand that your User Contributions may be copied by other Services users and discussed on and outside of the Services, and if you do not have the right to submit User Contributions for such use, it may subject you to liability. MONCH takes no responsibility and assumes no liability for any content Posted by you or any third party.

MONCH has the right but not the obligation to monitor and edit or remove any User Contributions. MONCH also has the right to terminate your access to all or part of the Services for any or no reason, including without limitation, any violation of these Terms. MONCH may exercise these rights at any time, without notice or liability to you or any third party.

## Submissions

MONCH receives questions and suggestions about our games and systems. MONCH does not accept unsolicited game or product ideas. If you submit product suggestions, questions, creative materials, ideas or other information about our Services or MONCH ("Submissions"), such Submissions, whether submitted via the Services or otherwise, will be non-confidential and shall automatically become the sole property of MONCH. MONCH shall own, and you hereby assign to MONCH, all right, title and interest, including all intellectual property rights, in and to such Submissions and MONCH shall be entitled to the unrestricted use and dissemination of these materials for any purpose, commercial or otherwise, without acknowledgment or compensation to you. You agree to execute any documentation required by MONCH (in our sole discretion) to confirm such assignment to, and unrestricted use and dissemination by, MONCH of such Submissions.

## Linking

You may link to publicly available portions of the Services if you do so in a way that is non-commercial, fair and does not damage or take advantage of our reputation, but you must not establish a link in such a way as to suggest any form of association, approval, or endorsement on our part. The Services must not be framed on any other website, platform or service. We reserve the right to withdraw linking permission without notice.

If the Services contain links to other sites and resources provided by third parties, these links are provided for your convenience only. We have no control over the contents of those sites or resources, and accept no responsibility for them or for any loss or damage that may arise from your use of them.

## Disclaimers and Limitation of Liability

Nothing in these Terms will prejudice the statutory rights that you may have as a consumer of the Services. Some countries, states, provinces or other jurisdictions do not allow the exclusion of certain warranties or the limitation of liability as stated in this section, so the below terms may not fully apply to you. Instead, in such jurisdictions, the exclusions and limitations below shall apply only to the extent permitted by the laws of such jurisdictions.

THE SERVICES AND ALL INFORMATION, CONTENT, MATERIALS, PRODUCTS (INCLUDING SOFTWARE), AND OTHER SERVICES INCLUDED ON OR OTHERWISE MADE AVAILABLE TO YOU THROUGH THE SERVICES ARE PROVIDED BY MONCH ON AN "AS IS" AND "AS AVAILABLE" BASIS. MONCH MAKES NO REPRESENTATIONS OR WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, AS TO THE OPERATION OF THE SERVICES, OR THE INFORMATION, CONTENT, MATERIALS, PRODUCTS (INCLUDING SOFTWARE), OR OTHER SERVICES INCLUDED ON OR OTHERWISE MADE AVAILABLE TO YOU THROUGH THE SERVICES. YOU EXPRESSLY AGREE THAT YOUR USE OF THE SERVICES IS AT YOUR SOLE RISK. TO THE FULL EXTENT PERMISSIBLE BY LAW, MONCH DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. MONCH DOES NOT WARRANT THAT THE SERVICES, INFORMATION, CONTENT, MATERIALS, PRODUCTS (INCLUDING SOFTWARE) OR OTHER SERVICES INCLUDED ON OR OTHERWISE MADE AVAILABLE TO YOU THROUGH THE SERVICES, MONCH'S SERVERS, OR ELECTRONIC COMMUNICATIONS SENT FROM MONCH ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS.

TO THE FULL EXTENT PERMISSIBLE BY LAW, MONCH WILL NOT BE LIABLE FOR ANY LOSS OF PROFITS OR ANY INDIRECT, INCIDENTAL, PUNITIVE, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN CONNECTION WITH THIS THESE TERMS. FURTHER, TO THE FULL EXTENT PERMISSIBLE BY LAW, MONCH'S AGGREGATE LIABILITY ARISING OUT OF OR IN CONNECTION WITH THESE TERMS WILL NOT EXCEED THE TOTAL AMOUNTS YOU HAVE PAID (IF ANY) TO MONCH UNDER THIS AGREEMENT DURING THE TWELVE (12) MONTHS IMMEDIATELY PRECEDING THE EVENTS GIVING RISE TO SUCH LIABILITY. THESE LIMITATIONS AND EXCLUSIONS REGARDING DAMAGES APPLY EVEN IF ANY REMEDY FAILS TO PROVIDE ADEQUATE COMPENSATION.

In some cases, may integrate directly with third parties, including but not limited to, online merchant platforms, mailing list platforms, and social media platforms ("Third Party APIs"). has no control over the uptime and functionality made available through Third Party APIs and as such certain aspects of the Platform could incur an outage outside of 's control, and certain aspects of the Platform's functionality could be impacted by changes of features made available through Third Party APIs.

The platform is subject to flaws and acknowledge that you are solely responsible for evaluating any code provided by the Platform. may experience cyber-attacks, unexpected surges in activity, or other operational or technical difficulties that may cause interruptions to or delays on the Platform. You accept the risk of the Platform failure resulting from unanticipated or heightened technical difficulties, including those resulting from sophisticated attacks, and you agree not to hold us accountable for any related losses.

## Indemnification

This section only applies to the extent permitted by applicable law. If you are prohibited by law from entering into the indemnification obligation below, then you assume, to the extent permitted by law, all liability for all claims, demands, actions, losses, liabilities, and expenses (including attorneys' fees, costs and expert witnesses' fees) that are the stated subject matter of the indemnification obligation below.

You agree to defend, indemnify, and hold harmless MONCH, its affiliates, and licensors, and their respective officers, directors, employees, contractors, agents, licensors, and suppliers from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) resulting from your User Contributions or access to or use of our Services (including, without limitation, Additional Benefits and Related Content) or violation of these Terms.

## Governing Law and Jurisdiction

Any dispute or claim by you arising out of or related to these Terms shall be governed by Colorado law, exclusive of its choice of law rules. For any disputes deemed not subject to binding individual arbitration, as provided in the section immediately below, you and MONCH agree to submit to the exclusive jurisdiction of the Superior Court of Colorado, or, if federal court jurisdiction exists, the United States District Court for the state of Colorado. You and MONCH agree to waive any jurisdictional, venue, or inconvenient forum objections to such courts (without affecting either party's rights to remove a case to federal court if permissible), as well as any right to a jury trial. The Convention on Contracts for the International Sale of Goods will not apply. Any law or regulation which provides that the language of a contract shall be construed against the drafter will not apply to these Terms. This paragraph will be interpreted as broadly as applicable law permits.

## Binding Individual Arbitration; No Class Actions

PLEASE READ THIS SECTION CAREFULLY. IT AFFECTS YOUR RIGHTS, INCLUDING YOUR RIGHT TO FILE A LAWSUIT IN COURT.

Most issues can be resolved quickly and amicably by contacting MONCH customer support at admin@monchtech.com But we understand that sometimes disputes can't be easily resolved by customer support. This Section explains how You and MONCH agree to resolve those disputes, including (where applicable) by binding, individual arbitration.

Arbitration is an alternative dispute-resolution procedure that allows us to resolve issues without the formality of going to court. Any dispute between You and MONCH is submitted to a neutral arbitrator (not a judge or jury) for fair and fast resolution. Arbitration is more efficient for both you and MONCH.

Disputes related to MONCH's End User License Agreement ("EULA"): If you have agreed to MONCH's End User License Agreement ("EULA"), "Disputes" as that term is defined in the EULA will be resolved as provided for in the EULA, including the EULA's "Binding Individual Arbitration" section. The dispute resolution terms below apply to disputes arising solely under these Terms and not to products or services governed by a EULA.

## Language

To the fullest extent permitted by law, the controlling language for these Terms is English. It is the express wish of the parties that these Terms and all related documents have been drawn up in English. Les parties déclarent qu'elles ont demandé et par les présentes confirment leur desir exprés que cette convention soit rédigee en anglais. Any translation has been provided for your convenience.

## Waiver and Severability

No waiver of these Terms by MONCH shall be deemed a further or continuing waiver of such term or condition or any other term or condition, and any failure of MONCH to assert a right or provision under these Terms shall not constitute a waiver of such right or provision.

If any provision of these Terms is held by a court of competent jurisdiction to be invalid, illegal, or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of these Terms will continue in full force and effect.

## Notice and Procedure for Making Claims of Copyright Infringement

In accordance with the Digital Millennium Copyright Act ("DMCA") and other applicable law, MONCH has adopted a policy of terminating, in appropriate circumstances as determined by MONCH, users or account holders who are deemed to be repeat infringers of the copyrights of others. MONCH may also at its sole discretion limit access to the Services and/or update, transfer, suspend, or terminate the accounts of any users who infringe the intellectual property rights of others, whether or not there is any repeat infringement.

If you believe that your work has been used on the Platform or in any other Services in a way that constitutes copyright infringement, please submit a Notice of Alleged Infringement ("DMCA Notice") to our Designated Copyright Agent as follows:

Legal Department
MONCH INC
2935 PATTERSON RD GRAND JUNCTION, CO 81504
+1 983 209 8078
Email: admin@monchtech.com

## Please include all of the following in your DMCA Notice:

- Identify the copyrighted work that you claim has been infringed. If your DMCA Notice covers multiple works, you may provide a representative list of such works.

- Identify the material that you claim is infringing, including a description of where the material is located. Your description must be reasonably sufficient to enable us to locate the material. Where possible, please include the URL of the webpage where the material is located.

- Provide your full legal name, mailing address, telephone number, and (if available) e-mail address.

- Include the following statement in the body of the DMCA Notice:

  > I have a good-faith belief that the use of the material is not authorized by the copyright owner, its agent, or the law. I represent that the information in this DMCA Notice is accurate and, under penalty of perjury, that I am the owner of the copyright or authorized to act on the copyright owner's behalf.

- Provide your electronic or physical signature.

- Please note that under 17 U.S.C. 512(f), if you knowingly misrepresent that material or activity is infringing, you may be liable for damages, including costs and attorneys' fees, incurred by us or our users. If you are unsure whether the material or activity you are reporting is infringing, you may wish to contact an attorney before filing a notification with us.

## Changes to These Terms

We may change these Terms from time to time. If we do, we'll provide notice of any changes, such as by posting the most recent version on our Services and updating the "Version" date below. You can view the latest Terms any time by clicking the "Terms of Use" link at the bottom of the applicable webpage. We encourage you to check for updates regularly. Your continued use of the Services following any notice we provide will confirm that you have agreed to the amended Terms. If you do not agree to the amended Terms, you must stop using the Services.

## Contact Information

Company Name: MONCH INC

Game: Warrior Fight IDLE Defense

Email: admin@monchtech.com

Address: 2935 PATTERSON RD GRAND JUNCTION, CO 81504