import SectionTitle from "../components/SectionTitle";
import { company } from "../data";

export default function AboutPage() {
  return (
    <div className="about-page page-shell">
      <section className="page-hero about-hero" data-reveal>
        <div className="page-hero-copy" data-reveal>
          <SectionTitle
            eyebrow="About Us"
            title="A small studio focused on clean game presentation and approachable entertainment."
            text={`${company.name} focuses on interactive entertainment experiences that are easy to understand, visually consistent, and suitable for broad digital audiences.`}
          />
        </div>
        <div className="about-hero-image glass-card" data-reveal>
          <img src={company.aboutImage} alt="Modern office corner representing the studio workspace." />
        </div>
      </section>

      <section className="content-section">
        <div className="highlights-grid">
          <article className="glass-card highlight-card" data-reveal>
            <span className="mini-label">What We Build</span>
            <h3>Game interfaces and playful digital products.</h3>
            <p>
              Our work is centered on consumer-facing interactive products,
              especially game experiences that combine visual clarity, lightweight
              progression, and a distinct presentation style.
            </p>
          </article>
          <article className="glass-card highlight-card" data-reveal>
            <span className="mini-label">How We Work</span>
            <h3>Small-team execution with practical scope control.</h3>
            <p>
              We prefer production choices that are sustainable: concise feature
              sets, readable UI systems, and communication that stays accurate to
              the actual state of the product.
            </p>
          </article>
          <article className="glass-card highlight-card" data-reveal>
            <span className="mini-label">Vision</span>
            <h3>Experiences that feel inviting from the first minute.</h3>
            <p>
              We want our titles to be understandable quickly, visually
              memorable, and structured in a way that makes repeated use feel
              rewarding instead of demanding.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
}
